# Precision-Digital-Protractor
A project to build and interface a precision digital protractor to a facting machine giving a resolution of 1/40 degree. The system employs a US Digital E6 Optical Encoder, Arduino Nano and Waveshare 1.5" colour OLED display.
